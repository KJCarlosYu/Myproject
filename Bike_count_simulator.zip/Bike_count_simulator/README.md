This is a bike rental counts simulator.

The data was provided by the professor and the result of the project is a machine learning model and an application.

The application is uploaded to streamlit cloud. However, it might be stopped if no one is using the application. Therefore, to see the application, you can run the streamlit document or contact me to restart the app.

The app is an individual project while the machine learning is done with the help of my group mate.